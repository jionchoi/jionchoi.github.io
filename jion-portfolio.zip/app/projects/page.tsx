import { ProjectsGrid } from "@/components/projects-grid"

export default function ProjectsPage() {
  return (
    <div className="py-20">
      <ProjectsGrid />
    </div>
  )
}
