import { AwardsShowcase } from "@/components/awards-showcase"

export default function AwardsPage() {
  return (
    <div className="py-20">
      <AwardsShowcase />
    </div>
  )
}
